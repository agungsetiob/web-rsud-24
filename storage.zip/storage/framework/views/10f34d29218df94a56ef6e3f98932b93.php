<!DOCTYPE html>
<html lang="en">

    <head>
        <meta charset="utf-8">
        <title><?php echo e($title); ?></title>
        <meta content="width=device-width, initial-scale=1.0" name="viewport">
        <meta content="rsud tanah bumbu" name="keywords">
        <meta content="rumah sakit umum daerah tanah bumbu amanah husada" name="description">
        <meta name="csrf-token" content="<?php echo e(csrf_token()); ?>">
        <link rel="preconnect" href="https://fonts.googleapis.com">
        <link rel="preconnect" href="https://fonts.gstatic.com" crossorigin>
        <link href="https://fonts.googleapis.com/css2?family=Open+Sans:wght@400;500;600&family=Playfair+Display:wght@400;500;600&display=swap" rel="stylesheet"> 
        <link rel="stylesheet" href="https://use.fontawesome.com/releases/v5.15.4/css/all.css"/>
        <link href="https://cdn.jsdelivr.net/npm/bootstrap-icons@1.4.1/font/bootstrap-icons.css" rel="stylesheet">
        <link href="<?php echo e(asset('lib/animate/animate.min.css')); ?>" rel="stylesheet">
        <link href="<?php echo e(asset('lib/owlcarousel/assets/owl.carousel.min.css')); ?>" rel="stylesheet">
        <link href="<?php echo e(asset('css/bootstrap.min.css')); ?>" rel="stylesheet">
        <link href="<?php echo e(asset('css/style.css')); ?>" rel="stylesheet">
        <link rel="shortcut icon" href="<?php echo e(asset('img/favicon.png')); ?>" type="image/x-icon"/>
        <!-- JavaScript Libraries -->
        <script src="https://ajax.googleapis.com/ajax/libs/jquery/3.6.4/jquery.min.js"></script>
        <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.0.0/dist/js/bootstrap.bundle.min.js"></script>
        <script src="<?php echo e(asset('lib/wow/wow.min.js')); ?>"></script>
        <script src="<?php echo e(asset('lib/easing/easing.min.js')); ?>"></script>
        <script src="<?php echo e(asset('lib/waypoints/waypoints.min.js')); ?>"></script>
        <script src="<?php echo e(asset('lib/owlcarousel/owl.carousel.min.js')); ?>"></script>
        <script src="<?php echo e(asset('vendor/tanbu/tanbu.min.js')); ?>"></script>
        <script src="<?php echo e(asset('vendor/tanbu/loading-states.js')); ?>"></script>
    </head>

    <body id="home" hx-ext="loading-states">

        <!-- Topbar Start -->
        <div id="beranda" class="container-fluid bg-dark px-5 d-none d-lg-block">
            <div class="row gx-0 align-items-center" style="height: 45px;">
                <div class="col-lg-8 text-center text-lg-start mb-lg-0">
                    <div class="d-flex flex-wrap">
                        <a href="https://maps.app.goo.gl/Q1FrsSHqmTuKRU776" class="text-light me-4" target="_blank"><i class="fas fa-map-marker-alt text-primary me-2"></i>Find Us</a>
                        <a href="#" class="text-light me-4"><i class="fas fa-phone-alt text-primary me-2"></i>+628115040540</a>
                        <a href="#" class="text-light me-4"><i class="fas fa-envelope text-primary me-2"></i>rsud.tanbu@gmail.com</a>
                        <a href="https://lapor.go.id" class="text-light me-0" target="_blank"><img class="me-2" src="<?php echo e(asset('img/lapor-color.png')); ?>" alt="Lapor" style="height:21px;"></a>
                    </div>
                </div>
                <div class="col-lg-4 text-center text-lg-end">
                    <div class="d-flex align-items-center justify-content-end">
                        <a href="#" class="btn btn-light btn-square border rounded-circle nav-fill me-3"><i class="fab fa-facebook-f"></i></a>
                        <a href="https://www.instagram.com/rsud_tanah_bumbu/" class="btn btn-light btn-square border rounded-circle nav-fill me-3"><i class="fab fa-instagram"></i></a>
                    </div>
                </div>
            </div>
        </div>
        <!-- Topbar End -->

        <!-- Navbar & Hero Start -->
        <div class="container-fluid position-relative p-0">
            <nav class="navbar navbar-expand-lg navbar-light bg-white px-4 px-lg-5 py-3 py-lg-0">
                <a href="/" class="navbar-brand p-0">
                    <!-- <h1 class="text-primary m-0"><i class="fas fa-star-of-life me-3"></i>Terapia</h1> -->
                    <img src="<?php echo e(url('storage/logors.png')); ?>" alt="Logo">
                </a>
                <button class="navbar-toggler" type="button" data-bs-toggle="collapse" data-bs-target="#navbarCollapse" title="navbar toggle">
                    <span class="fa fa-bars"></span>
                </button>
                <div class="collapse navbar-collapse" id="navbarCollapse">
                    <div class="navbar-nav ms-auto py-0">
                        <a href="#" class="nav-item nav-link"
                        hx-get="<?php echo e(url('/')); ?>" 
                        hx-trigger="click" 
                        hx-target="#app" 
                        hx-swap="outerHTML transition:true"
                        hx-push-url="true"
                        hx-indicator="#loadingIndicator">Beranda</a>
                        <a href="#" class="nav-item nav-link"
                        hx-get="<?php echo e(url('/blog')); ?>" 
                        hx-trigger="click" 
                        hx-target="#app" 
                        hx-swap="outerHTML transition:true"
                        hx-push-url="true"
                        hx-indicator="#loadingIndicator">Blog</a>
                        <a href="#" class="nav-item nav-link"
                        hx-get="<?php echo e(url('/profil')); ?>" 
                        hx-trigger="click" 
                        hx-target="#app" 
                        hx-swap="outerHTML transition:true"
                        hx-push-url="true"
                        hx-indicator="#loadingIndicator">Profil</a>
                        <a href="#" class="nav-item nav-link"
                        hx-get="<?php echo e(url('/layanan')); ?>" 
                        hx-trigger="click" 
                        hx-target="#app" 
                        hx-swap="outerHTML transition:true"
                        hx-push-url="true"
                        hx-indicator="#loadingIndicator">Layanan</a>
                        <a id="kontak" href="" class="nav-item nav-link"
                        hx-get="<?php echo e(url('/kontak')); ?>" 
                        hx-trigger="click" 
                        hx-target="#app" 
                        hx-swap="outerHTML transition:true"
                        hx-push-url="true"
                        hx-indicator="#loadingIndicator">Kontak</a>
                        <div class="nav-item dropdown">
                            <a href="#" class="nav-link dropdown-toggle" data-bs-toggle="dropdown">Pages</a>
                            <div class="dropdown-menu m-0">
                                <a href="appointment.html" class="dropdown-item">Al-Qur'an Digital</a>
                                <a href="feature.html" class="dropdown-item">Standar Pelayanan</a>
                                <a href="blog.html" class="dropdown-item">Survey</a>
                                <a href="team.html" class="dropdown-item">Dokumen Publik</a>
                                <a href="testimonial.html" class="dropdown-item">Top Author</a>
                            </div>
                        </div>
                    </div>
                    <a href="/login" class="btn btn-primary rounded-pill text-white py-2 px-4 flex-wrap flex-sm-shrink-0">Login</a>
                </div>
            </nav>
        </div>

        <?php echo $__env->yieldContent('content'); ?>
        <?php echo $__env->make('main.partials.hx-indicator', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
        <!-- Copyright Start -->
        <div class="container-fluid copyright py-4">
            <div class="container">
                <div class="row g-4 align-items-center justify-content-center">
                    <div class="col-md-6 text-center mb-md-0">
                        <span class="text-white"><a href="#"><i class="fas fa-copyright text-light me-2"></i>IT PDE</a> RSUD RS Amanah Husada</span>
                    </div>
                </div>
            </div>
        </div>
        <!-- Copyright End -->

        <!-- Back to Top -->
        <a href="#" class="btn btn-primary btn-lg-square back-to-top"><i class="fa fa-arrow-up"></i></a>
        <script src="<?php echo e(asset('js/main.js')); ?>"></script>     
    </body>
</html><?php /**PATH /Users/agungs/Sites/web-rsud/resources/views/layouts/page-layout.blade.php ENDPATH**/ ?>