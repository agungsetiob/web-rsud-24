<div id="layanan" class="container-fluid feature py-5">
    <div class="container py-5">
        <div class="section-title mb-5 wow fadeInUp" data-wow-delay="0.1s">
            <div class="sub-style">
                <h4 class="sub-title px-3 mb-0">Layanan</h4>
            </div>
            <h3 class="mb-4">Poliklinik dan Layanan Kami</h3>
        </div>
        <div class="row g-4 justify-content-center">
            <div class="col-md-6 col-lg-4 col-xl-3 wow fadeInUp" data-wow-delay="0.1s">
                <div class="row-cols-1 feature-item p-4">
                    <div class="col-12">
                        <div class="feature-icon mb-4">
                            <div class="p-3 d-inline-flex bg-white rounded">
                                <i class="fas fa-diagnoses fa-4x text-primary"></i>
                            </div>
                        </div>
                        <div class="feature-content d-flex flex-column">
                            <h5 class="mb-4">Lab Patologi Klinis</h5>
                            <p class="mb-0">Dolor, sit amet consectetur adipisicing elit. Soluta inventore cum
                                accusamus,</p>
                        </div>
                    </div>
                </div>
            </div>
            <div class="col-12 text-center wow fadeInUp" data-wow-delay="0.2s">
                <a class="btn btn-primary rounded-pill text-white py-3 px-5">More Details</a>
            </div>
        </div>
    </div>
</div><?php /**PATH /Users/agungs/Sites/web-rsud/resources/views/main/partials/services.blade.php ENDPATH**/ ?>