<div id="loadingIndicator" class="htmx-indicator d-flex align-items-center justify-content-center">
    <i class="fas fa-spinner fa-spin fa-5x text-primary" style="position: absolute; z-index:2;"></i>
</div>
<style>
    #loadingIndicator{
        position: fixed; 
        top: 50%; 
        left: 50%; 
        transform: translate(-50%, -50%); 
        z-index: 100001;
    }
</style><?php /**PATH /Users/agungs/Sites/web-rsud/resources/views/main/partials/hx-indicator.blade.php ENDPATH**/ ?>