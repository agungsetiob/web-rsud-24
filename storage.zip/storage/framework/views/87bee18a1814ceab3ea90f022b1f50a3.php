    
        <?php $__env->startSection('content'); ?>
            <?php $__env->startFragment('beranda'); ?>
            <div id="app">
                <?php echo $__env->make('main.partials.carousels', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
                <?php echo $__env->make('main.partials.blog', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
                <?php echo $__env->make('main.partials.profile', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
                <?php echo $__env->make('main.partials.services', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
                <?php echo $__env->make('main.partials.contact', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
                <?php echo $__env->make('main.partials.doctors', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
                <?php echo $__env->make('main.partials.faqs', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
            </div>
            <script>
                $(".header-carousel").owlCarousel({
                    animateOut: 'slideOutDown',
                    items: 1,
                    autoplay: true,
                    smartSpeed: 1000,
                    dots: false,
                    loop: true,
                    nav : true,
                    navText : [
                        '<i class="bi bi-arrow-left"></i>',
                        '<i class="bi bi-arrow-right"></i>'
                    ],
                });
            </script>
            <?php echo $__env->stopFragment(); ?>
        <?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.page-layout', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /Users/agungs/Sites/web-rsud/resources/views/main/index.blade.php ENDPATH**/ ?>