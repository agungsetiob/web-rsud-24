<div class="header-carousel owl-carousel">
    <div class="header-carousel-item">
        <img src="<?php echo e(asset('img/carousel-1.jpg')); ?>" class="img-fluid w-100" alt="Image">
        <div class="carousel-caption">
            <div class="carousel-caption-content p-3">
                <h5 class="text-white text-uppercase fw-bold mb-4" style="letter-spacing: 3px;">RSUD Rumah Sehat Amanah
                    Husada</h5>
                <h1 class="display-1 text-capitalize text-white mb-4">Senyum Santun Sapa</h1>
            </div>
        </div>
    </div>
    <div class="header-carousel-item">
        <img src="<?php echo e(asset('img/carousel-2.jpg')); ?>" class="img-fluid w-100" alt="Image">
        <div class="carousel-caption">
            <div class="carousel-caption-content p-3">
                <h5 class="text-white text-uppercase fw-bold mb-4" style="letter-spacing: 3px;">RSUD Rumah Sehat Amanah
                    Husada</h5>
                <h1 class="display-1 text-capitalize text-white mb-4">Senyum Santun Sapa</h1>
            </div>
        </div>
    </div>
    <div class="header-carousel-item">
        <img src="<?php echo e(asset('img/carousel-3.png')); ?>" class="img-fluid w-100" alt="Image">
        <div class="carousel-caption">
            <div class="carousel-caption-content p-3">
                <h5 class="text-white text-uppercase fw-bold mb-4" style="letter-spacing: 3px;">RSUD Rumah Sehat Amanah
                    Husada</h5>
                <h1 class="display-1 text-capitalize text-white mb-4">Senyum Santun Sapa</h1>
            </div>
        </div>
    </div>
</div><?php /**PATH /Users/agungs/Sites/web-rsud/resources/views/main/partials/carousels.blade.php ENDPATH**/ ?>